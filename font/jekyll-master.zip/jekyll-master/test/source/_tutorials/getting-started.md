---
title: "Getting Started"
lesson: 1
approx_time: 10 mins
---

The first thing you need is a working installation of Ruby. Install from [the official website](https://www.ruby-lang.org/en/documentation/installation/).
